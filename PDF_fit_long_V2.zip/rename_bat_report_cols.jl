using BAT, HDF5

smpls = bat_read("simsamples-42.h5").result
r = bat_report(smpls)
tbl = r[3]

for row in tbl.rows[begin+1:end]
   row[1] = replace(
       row[1],
       "θ" => "Δ",
       "Beta1" => "δ¹",
       "Beta2" => "δ²",
       "beta0" => "δ⁰",
       "[1]" => "₁", "[2]" => "₂", "[3]" => "₃", "[4]" => "₄", "[5]" => "₅", "[6]" => "₆", "[7]" => "₇", "[8]" => "₈", "[9]" => "₉",
       "_1" => "₁", "_2" => "₂", "_3" => "₃", "_4" => "₄", "_5" => "₅", "_6" => "₆", "_7" => "₇", "_8" => "₈", "_9" => "₉",
       "K_" => "K", "λ_" => "λ", "g1" => "g₁", "g2" => "g₂"
   )
end

join([row[1] for row in tbl.rows[begin+1:end]], ", ")

display(r)
